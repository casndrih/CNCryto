"""
Core type definitions for the forex signal system.
Precision-typed with validation for financial accuracy.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Optional, Literal
import uuid


class Direction(Enum):
    """Trade direction with explicit semantics."""
    BUY = "Buy"
    SELL = "Sell"
    FLAT = "Flat"

    @classmethod
    def from_string(cls, value: str) -> Direction:
        normalized = value.strip().lower()
        if normalized in ("buy", "long", "b"):
            return cls.BUY
        if normalized in ("sell", "short", "s"):
            return cls.SELL
        raise ValueError(f"Invalid direction: {value}")


class SignalStrength(Enum):
    """Signal confidence classification."""
    STRONG = "Strong"
    GENERAL = "General"
    WEAK = "Weak"

    @classmethod
    def from_string(cls, value: str) -> SignalStrength:
        normalized = value.strip().lower()
        if normalized in ("strong", "high", "s"):
            return cls.STRONG
        if normalized in ("general", "medium", "normal", "g"):
            return cls.GENERAL
        if normalized in ("weak", "low", "w"):
            return cls.WEAK
        return cls.GENERAL  # Default fallback


class TradeStatus(Enum):
    """Trade lifecycle states."""
    PENDING = "Pending"
    OPEN = "Open"
    CLOSED_TP = "Closed_TakeProfit"
    CLOSED_SL = "Closed_StopLoss"
    CLOSED_TIME = "Closed_TimeExit"
    CLOSED_MANUAL = "Closed_Manual"
    REJECTED = "Rejected"


class MarketRegime(Enum):
    """Market regime classification for regime-aware filtering."""
    TRENDING_UP = "Trending_Up"
    TRENDING_DOWN = "Trending_Down"
    RANGING = "Ranging"
    VOLATILE = "Volatile"
    UNKNOWN = "Unknown"


@dataclass(frozen=True, slots=True)
class PriceLevel:
    """Immutable price level with pip-aware precision."""
    value: Decimal
    symbol: str

    def __post_init__(self):
        # Validate precision matches symbol pipette
        pip_digits = 3 if "JPY" in self.symbol.upper() else 5
        quantize_exp = Decimal(f"1e-{pip_digits}")
        object.__setattr__(self, 'value', self.value.quantize(quantize_exp, rounding=ROUND_HALF_UP))

    def pips_from(self, other: PriceLevel) -> Decimal:
        """Calculate pip distance between two price levels."""
        if self.symbol != other.symbol:
            raise ValueError("Symbol mismatch for pip calculation")
        pip_size = Decimal("0.01") if "JPY" in self.symbol.upper() else Decimal("0.0001")
        diff = abs(self.value - other.value)
        return (diff / pip_size).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)

    def add_pips(self, pips: Decimal) -> PriceLevel:
        """Return new PriceLevel offset by pips."""
        pip_size = Decimal("0.01") if "JPY" in self.symbol.upper() else Decimal("0.0001")
        new_value = self.value + (pips * pip_size)
        return PriceLevel(new_value, self.symbol)

    def subtract_pips(self, pips: Decimal) -> PriceLevel:
        """Return new PriceLevel offset by negative pips."""
        return self.add_pips(-pips)


@dataclass(frozen=True, slots=True)
class ForexSignal:
    """Validated forex trading signal with full metadata."""
    symbol: str
    direction: Direction
    strength: SignalStrength
    timestamp: datetime
    source: str = "XTrendSpeed"
    entry_price: Optional[PriceLevel] = None
    stop_loss: Optional[PriceLevel] = None
    take_profit: Optional[PriceLevel] = None
    signal_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    raw_data: dict = field(default_factory=dict)

    def __post_init__(self):
        # Normalize symbol format
        object.__setattr__(self, 'symbol', self.symbol.upper().replace("/", "").replace("-", ""))
        # Ensure timezone awareness
        if self.timestamp.tzinfo is None:
            object.__setattr__(self, 'timestamp', self.timestamp.replace(tzinfo=timezone.utc))

    @property
    def is_buy(self) -> bool:
        return self.direction == Direction.BUY

    @property
    def is_sell(self) -> bool:
        return self.direction == Direction.SELL

    def risk_reward_ratio(self) -> Optional[Decimal]:
        """Calculate R:R if SL and TP are defined."""
        if not self.entry_price or not self.stop_loss or not self.take_profit:
            return None
        risk = self.entry_price.pips_from(self.stop_loss)
        reward = self.entry_price.pips_from(self.take_profit)
        if risk == 0:
            return None
        return (reward / risk).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass(frozen=True, slots=True)
class PositionSize:
    """Position sizing calculation result."""
    lots: Decimal
    units: Decimal
    risk_amount: Decimal
    risk_pct: Decimal
    margin_required: Decimal
    pip_value: Decimal

    def __str__(self) -> str:
        return (f"{self.lots:.2f} lots ({self.units:,.0f} units) | "
                f"Risk: {self.risk_amount:.2f} ({self.risk_pct:.2%}) | "
                f"Margin: {self.margin_required:.2f} | Pip Value: {self.pip_value:.2f}")


@dataclass(frozen=True, slots=True)
class TradeResult:
    """Completed trade with full P&L attribution."""
    signal: ForexSignal
    entry_price: PriceLevel
    exit_price: PriceLevel
    exit_time: datetime
    exit_reason: TradeStatus
    position_size: PositionSize
    gross_pnl_pips: Decimal
    gross_pnl_currency: Decimal
    commission: Decimal
    swap: Decimal
    net_pnl_currency: Decimal
    mae_pips: Decimal  # Maximum Adverse Excursion
    mfe_pips: Decimal  # Maximum Favorable Excursion
    duration_minutes: int
    trade_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    @property
    def is_winner(self) -> bool:
        return self.net_pnl_currency > 0

    @property
    def r_multiple(self) -> Decimal:
        """P&L expressed in R multiples (risk units)."""
        risk_pips = self.signal.entry_price.pips_from(self.signal.stop_loss) if self.signal.entry_price and self.signal.stop_loss else Decimal("1")
        if risk_pips == 0:
            return Decimal("0")
        return (self.gross_pnl_pips / risk_pips).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass(frozen=True, slots=True)
class OHLCV:
    """Single candle with validation."""
    timestamp: datetime
    open: PriceLevel
    high: PriceLevel
    low: PriceLevel
    close: PriceLevel
    volume: Decimal = Decimal("0")

    def __post_init__(self):
        # Validate OHLC relationships
        if not (self.low.value <= self.open.value <= self.high.value):
            raise ValueError("Invalid OHLC: low <= open <= high violated")
        if not (self.low.value <= self.close.value <= self.high.value):
            raise ValueError("Invalid OHLC: low <= close <= high violated")
        # Ensure all prices same symbol
        symbols = {self.open.symbol, self.high.symbol, self.low.symbol, self.close.symbol}
        if len(symbols) != 1:
            raise ValueError("All price levels must have same symbol")


@dataclass(frozen=True, slots=True)
class AccountState:
    """Trading account snapshot."""
    equity: Decimal
    balance: Decimal
    free_margin: Decimal
    used_margin: Decimal
    margin_level: Decimal
    open_positions: int
    daily_pnl: Decimal
    max_drawdown_pct: Decimal
    currency: str = "USD"

    def can_trade(self, risk_amount: Decimal, required_margin: Decimal, max_daily_loss_pct: Decimal = Decimal("0.03")) -> tuple[bool, str]:
        """Check if new trade passes risk gates."""
        if self.daily_pnl <= -abs(self.equity * max_daily_loss_pct):
            return False, f"Daily loss limit hit: {self.daily_pnl:.2f}"
        if self.free_margin < required_margin:
            return False, f"Insufficient margin: {self.free_margin:.2f} < {required_margin:.2f}"
        if self.margin_level < 200:
            return False, f"Margin level too low: {self.margin_level:.1f}%"
        return True, "OK"