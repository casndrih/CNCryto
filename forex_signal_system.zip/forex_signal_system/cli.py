"""
Command-line interface for the Forex Signal System.
"""

from __future__ import annotations
import argparse
import sys
import logging
from pathlib import Path
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from .orchestrator import create_system, ForexSignalSystem
from .config import SystemConfig, get_config
from .signal_parser import XTrendSpeedParser
from .types import ForexSignal, Direction, SignalStrength, PriceLevel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


def setup_config(args) -> SystemConfig:
    """Build configuration from CLI args."""
    config = get_config()

    if args.risk_per_trade:
        config.risk.risk_per_trade_pct = Decimal(str(args.risk_per_trade))
    if args.max_daily_loss:
        config.risk.max_daily_loss_pct = Decimal(str(args.max_daily_loss))
    if args.min_rr:
        config.risk.min_risk_reward = Decimal(str(args.min_rr))
    if args.timeframe:
        config.backtest.data_timeframe = args.timeframe
    if args.start_date:
        config.backtest.start_date = args.start_date
    if args.end_date:
        config.backtest.end_date = args.end_date
    if args.initial_equity:
        config.backtest.initial_equity = Decimal(str(args.initial_equity))

    return config


def cmd_parse(args):
    """Parse signals from text input."""
    parser = XTrendSpeedParser()

    if args.input_file:
        text = Path(args.input_file).read_text()
    else:
        text = sys.stdin.read()

    signals = parser.parse(text)

    print(f"\nParsed {len(signals)} signals:")
    print("-" * 80)
    for s in signals:
        print(f"{s.symbol:8} | {s.direction.value:4} | {s.strength.value:7} | {s.timestamp.strftime('%H:%M')} | ID: {s.signal_id}")

    if args.output:
        import json
        data = [{
            "signal_id": s.signal_id,
            "symbol": s.symbol,
            "direction": s.direction.value,
            "strength": s.strength.value,
            "timestamp": s.timestamp.isoformat(),
            "source": s.source,
        } for s in signals]
        Path(args.output).write_text(json.dumps(data, indent=2))
        print(f"\nSaved to {args.output}")


def cmd_backtest(args):
    """Run backtest on signals with historical data."""
    config = setup_config(args)
    system = create_system(config)

    # Load signals
    if args.signals_file:
        signals = system.load_signals_from_file(Path(args.signals_file))
    else:
        # Use demo signals from XTrend Speed
        signals = create_demo_signals()
        print(f"Using {len(signals)} demo signals")

    if not signals:
        print("No signals to backtest")
        return

    # Track signals
    system.track_signals(signals, "CLI backtest")

    # Fetch price data
    symbols = list(set(s.symbol for s in signals))
    end_date = datetime.fromisoformat(args.end_date).replace(tzinfo=timezone.utc) if args.end_date else datetime.now(timezone.utc)
    start_date = datetime.fromisoformat(args.start_date).replace(tzinfo=timezone.utc) if args.start_date else end_date - timedelta(days=90)

    print(f"\nFetching price data for {len(symbols)} symbols: {start_date.date()} to {end_date.date()}")
    price_data = system.fetch_price_data(symbols, args.timeframe or config.backtest.data_timeframe, start_date, end_date)

    if not price_data:
        print("No price data fetched")
        return

    # Run backtest
    print("\nRunning backtest...")
    result = system.run_backtest(signals, price_data)

    # Generate report
    print("\nGenerating report...")
    report = system.generate_report(result)

    # Print summary
    summary = report["summary"]
    print("\n" + "=" * 60)
    print("BACKTEST RESULTS")
    print("=" * 60)
    for k, v in summary.items():
        if isinstance(v, float):
            print(f"  {k:25}: {v:.4f}")
        else:
            print(f"  {k:25}: {v}")
    print(f"\nReport saved to: {report['output_dir']}")


def cmd_analyze(args):
    """Analyze current market regime for symbols."""
    config = setup_config(args)
    system = create_system(config)

    symbols = args.symbols.split(",") if args.symbols else list(config.symbols.keys())[:10]
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=200)

    print(f"\nFetching data for regime analysis...")
    price_data = system.fetch_price_data(symbols, config.backtest.data_timeframe, start_date, end_date)

    regimes = system.analyze_regime(price_data)

    print("\n" + "=" * 60)
    print("CURRENT MARKET REGIMES")
    print("=" * 60)
    for symbol, regime in regimes.items():
        print(f"  {symbol:8}: {regime}")


def cmd_validate(args):
    """Validate a signal against risk rules."""
    config = setup_config(args)
    system = create_system(config)

    # Create signal from args
    signal = ForexSignal(
        symbol=args.symbol.upper(),
        direction=Direction.from_string(args.direction),
        strength=SignalStrength.from_string(args.strength),
        timestamp=datetime.now(timezone.utc),
        source="CLI",
        entry_price=PriceLevel(Decimal(str(args.entry)), args.symbol) if args.entry else None,
        stop_loss=PriceLevel(Decimal(str(args.sl)), args.symbol) if args.sl else None,
        take_profit=PriceLevel(Decimal(str(args.tp)), args.symbol) if args.tp else None,
    )

    approved, reason, details = system.validate_signal(signal)

    print("\n" + "=" * 60)
    print("SIGNAL VALIDATION")
    print("=" * 60)
    print(f"  Symbol:      {signal.symbol}")
    print(f"  Direction:   {signal.direction.value}")
    print(f"  Strength:    {signal.strength.value}")
    print(f"  Entry:       {signal.entry_price.value if signal.entry_price else 'N/A'}")
    print(f"  Stop Loss:   {signal.stop_loss.value if signal.stop_loss else 'N/A'}")
    print(f"  Take Profit: {signal.take_profit.value if signal.take_profit else 'N/A'}")
    print(f"  R:R:         {signal.risk_reward_ratio() or 'N/A'}")
    print("-" * 60)
    print(f"  APPROVED:    {'YES' if approved else 'NO'}")
    print(f"  Reason:      {reason}")
    if details:
        print(f"  Size:        {details['position_size']}")


def cmd_track(args):
    """View tracked signals and performance."""
    config = setup_config(args)
    system = create_system(config)

    if args.stats:
        stats = system.tracker.get_performance_stats()
        print("\n" + "=" * 60)
        print("PERFORMANCE STATISTICS")
        print("=" * 60)
        for k, v in stats.items():
            if isinstance(v, float):
                print(f"  {k:25}: {v:.4f}")
            else:
                print(f"  {k:25}: {v}")
    else:
        signals = system.tracker.get_signals(
            symbol=args.symbol.upper() if args.symbol else None,
            status=args.status,
            limit=args.limit
        )
        print(f"\nTracked Signals ({len(signals)}):")
        print("-" * 100)
        for s in signals:
            exec_info = f" @ {s.execution_price.value}" if s.execution_price else ""
            print(f"{s.signal.symbol:8} | {s.signal.direction.value:4} | {s.signal.strength.value:7} | "
                  f"{s.signal.timestamp.strftime('%Y-%m-%d %H:%M')} | {s.status:10} | ID: {s.signal.signal_id}{exec_info}")


def create_demo_signals() -> list[ForexSignal]:
    """Create demo signals matching the XTrend Speed data we scraped."""
    now = datetime.now(timezone.utc).replace(hour=1, minute=8, second=0, microsecond=0)

    demo_data = [
        ("AUDUSD", "Sell", "General"),
        ("EURUSD", "Sell", "General"),
        ("USDJPY", "Buy", "Strong"),
        ("GBPUSD", "Sell", "General"),
        ("NZDUSD", "Sell", "General"),
        ("USDCAD", "Buy", "General"),
        ("USDCHF", "Buy", "Strong"),
        ("AUDJPY", "Sell", "General"),
        ("EURGBP", "Sell", "General"),
        ("EURJPY", "Sell", "General"),
    ]

    signals = []
    for symbol, direction, strength in demo_data:
        signals.append(ForexSignal(
            symbol=symbol,
            direction=Direction.from_string(direction),
            strength=SignalStrength.from_string(strength),
            timestamp=now,
            source="XTrendSpeed",
        ))
    return signals


def main():
    parser = argparse.ArgumentParser(
        description="Forex Signal Analysis & Backtesting System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Parse signals from scraped text
  python -m forex_signal_system.cli parse -i signals.txt -o signals.json

  # Run backtest on demo signals
  python -m forex_signal_system.cli backtest --start-date 2024-01-01 --end-date 2024-12-31

  # Analyze current regimes
  python -m forex_signal_system.cli analyze --symbols EURUSD,GBPUSD,USDJPY

  # Validate a signal
  python -m forex_signal_system.cli validate --symbol EURUSD --direction Sell --entry 1.0850 --sl 1.0900 --tp 1.0750

  # View tracked signals
  python -m forex_signal_system.cli track --stats
        """
    )

    # Global options
    parser.add_argument("--risk-per-trade", type=float, help="Risk per trade (e.g., 0.01 for 1%)")
    parser.add_argument("--max-daily-loss", type=float, help="Max daily loss (e.g., 0.03 for 3%)")
    parser.add_argument("--min-rr", type=float, help="Minimum risk:reward ratio")
    parser.add_argument("--timeframe", choices=["M1", "M5", "M15", "M30", "H1", "H4", "D1"], help="Data timeframe")
    parser.add_argument("--start-date", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end-date", help="End date (YYYY-MM-DD)")
    parser.add_argument("--initial-equity", type=float, help="Initial equity for backtest")

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Parse command
    p_parse = subparsers.add_parser("parse", help="Parse signals from text/JSON")
    p_parse.add_argument("-i", "--input-file", help="Input file (default: stdin)")
    p_parse.add_argument("-o", "--output", help="Output JSON file")
    p_parse.set_defaults(func=cmd_parse)

    # Backtest command
    p_bt = subparsers.add_parser("backtest", help="Run backtest on signals")
    p_bt.add_argument("--signals-file", help="JSON file with signals")
    p_bt.set_defaults(func=cmd_backtest)

    # Analyze command
    p_an = subparsers.add_parser("analyze", help="Analyze market regimes")
    p_an.add_argument("--symbols", help="Comma-separated symbols (default: all major pairs)")
    p_an.set_defaults(func=cmd_analyze)

    # Validate command
    p_val = subparsers.add_parser("validate", help="Validate a signal against risk rules")
    p_val.add_argument("--symbol", required=True, help="Symbol (e.g., EURUSD)")
    p_val.add_argument("--direction", required=True, choices=["Buy", "Sell"], help="Direction")
    p_val.add_argument("--strength", default="General", choices=["Strong", "General", "Weak"], help="Signal strength")
    p_val.add_argument("--entry", type=float, help="Entry price")
    p_val.add_argument("--sl", type=float, help="Stop loss price")
    p_val.add_argument("--tp", type=float, help="Take profit price")
    p_val.set_defaults(func=cmd_validate)

    # Track command
    p_tr = subparsers.add_parser("track", help="View tracked signals and performance")
    p_tr.add_argument("--symbol", help="Filter by symbol")
    p_tr.add_argument("--status", choices=["tracked", "executed", "expired", "cancelled"], help="Filter by status")
    p_tr.add_argument("--limit", type=int, default=100, help="Max results")
    p_tr.add_argument("--stats", action="store_true", help="Show performance statistics")
    p_tr.set_defaults(func=cmd_track)

    args = parser.parse_args()

    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()