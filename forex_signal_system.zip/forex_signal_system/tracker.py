"""
Signal tracking and trade journaling system.
Persistent storage with SQLite for paper/live trade logging.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Optional, Literal
import sqlite3
import json
import logging
import threading
from contextlib import contextmanager

from .types import ForexSignal, TradeResult, TradeStatus, PositionSize, PriceLevel, Direction, SignalStrength

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class TrackedSignal:
    """Signal with tracking metadata."""
    signal: ForexSignal
    tracked_at: datetime
    status: Literal["tracked", "executed", "expired", "cancelled"] = "tracked"
    execution_price: Optional[PriceLevel] = None
    execution_time: Optional[datetime] = None
    trade_id: Optional[str] = None
    notes: str = ""


@dataclass(frozen=True, slots=True)
class JournalEntry:
    """Trading journal entry for post-trade analysis."""
    trade_id: str
    signal_id: str
    symbol: str
    direction: str
    entry_time: datetime
    entry_price: Decimal
    exit_time: Optional[datetime]
    exit_price: Optional[Decimal]
    exit_reason: Optional[str]
    position_size: Decimal
    risk_pips: Decimal
    reward_pips: Decimal
    gross_pnl_pips: Decimal
    net_pnl_currency: Decimal
    r_multiple: Decimal
    mae_pips: Decimal
    mfe_pips: Decimal
    duration_minutes: int
    regime: str
    setup_quality: int  # 1-5 self-rating
    execution_quality: int  # 1-5 self-rating
    psychology_notes: str
    market_notes: str
    lessons_learned: str


class SignalTracker:
    """
    Persistent signal and trade tracker with SQLite backend.
    Thread-safe for concurrent access.
    """

    def __init__(self, db_path: Path = Path("./data/signals.db")):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS signals (
                    id TEXT PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    strength TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    source TEXT NOT NULL,
                    entry_price TEXT,
                    stop_loss TEXT,
                    take_profit TEXT,
                    raw_data TEXT,
                    tracked_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'tracked',
                    execution_price TEXT,
                    execution_time TEXT,
                    trade_id TEXT,
                    notes TEXT DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS trades (
                    id TEXT PRIMARY KEY,
                    signal_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    entry_time TEXT NOT NULL,
                    entry_price TEXT NOT NULL,
                    exit_time TEXT,
                    exit_price TEXT,
                    exit_reason TEXT,
                    position_size TEXT NOT NULL,
                    risk_pips TEXT NOT NULL,
                    reward_pips TEXT NOT NULL,
                    gross_pnl_pips TEXT NOT NULL,
                    gross_pnl_currency TEXT NOT NULL,
                    commission TEXT NOT NULL,
                    swap TEXT NOT NULL,
                    net_pnl_currency TEXT NOT NULL,
                    mae_pips TEXT NOT NULL,
                    mfe_pips TEXT NOT NULL,
                    duration_minutes INTEGER NOT NULL,
                    r_multiple TEXT NOT NULL,
                    FOREIGN KEY (signal_id) REFERENCES signals(id)
                );

                CREATE TABLE IF NOT EXISTS journal (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trade_id TEXT NOT NULL UNIQUE,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    entry_time TEXT NOT NULL,
                    entry_price TEXT NOT NULL,
                    exit_time TEXT,
                    exit_price TEXT,
                    exit_reason TEXT,
                    position_size TEXT NOT NULL,
                    risk_pips TEXT NOT NULL,
                    reward_pips TEXT NOT NULL,
                    gross_pnl_pips TEXT NOT NULL,
                    net_pnl_currency TEXT NOT NULL,
                    r_multiple TEXT NOT NULL,
                    mae_pips TEXT NOT NULL,
                    mfe_pips TEXT NOT NULL,
                    duration_minutes INTEGER NOT NULL,
                    regime TEXT NOT NULL,
                    setup_quality INTEGER,
                    execution_quality INTEGER,
                    psychology_notes TEXT DEFAULT '',
                    market_notes TEXT DEFAULT '',
                    lessons_learned TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (trade_id) REFERENCES trades(id)
                );

                CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);
                CREATE INDEX IF NOT EXISTS idx_signals_timestamp ON signals(timestamp);
                CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status);
                CREATE INDEX IF NOT EXISTS idx_trades_signal ON trades(signal_id);
                CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
                CREATE INDEX IF NOT EXISTS idx_trades_entry ON trades(entry_time);
            """)

    @contextmanager
    def _conn(self):
        """Thread-safe database connection."""
        with self._lock:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            conn.row_factory = sqlite3.Row
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def track_signal(self, signal: ForexSignal, notes: str = "") -> str:
        """Record a new signal for tracking."""
        tracked = TrackedSignal(
            signal=signal,
            tracked_at=datetime.now(timezone.utc),
            notes=notes
        )

        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO signals
                (id, symbol, direction, strength, timestamp, source,
                 entry_price, stop_loss, take_profit, raw_data,
                 tracked_at, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                signal.signal_id,
                signal.symbol,
                signal.direction.value,
                signal.strength.value,
                signal.timestamp.isoformat(),
                signal.source,
                str(signal.entry_price.value) if signal.entry_price else None,
                str(signal.stop_loss.value) if signal.stop_loss else None,
                str(signal.take_profit.value) if signal.take_profit else None,
                json.dumps(signal.raw_data),
                tracked.tracked_at.isoformat(),
                tracked.status,
                tracked.notes
            ))

        logger.info(f"Tracked signal {signal.signal_id}: {signal.symbol} {signal.direction.value}")
        return signal.signal_id

    def update_signal_status(self, signal_id: str, status: str,
                             execution_price: Optional[PriceLevel] = None,
                             execution_time: Optional[datetime] = None,
                             trade_id: Optional[str] = None):
        """Update signal tracking status."""
        with self._conn() as conn:
            conn.execute("""
                UPDATE signals
                SET status = ?, execution_price = ?, execution_time = ?, trade_id = ?
                WHERE id = ?
            """, (
                status,
                str(execution_price.value) if execution_price else None,
                execution_time.isoformat() if execution_time else None,
                trade_id,
                signal_id
            ))

    def record_trade(self, trade: TradeResult) -> str:
        """Record a completed trade."""
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO trades
                (id, signal_id, symbol, direction, entry_time, entry_price,
                 exit_time, exit_price, exit_reason, position_size,
                 risk_pips, reward_pips, gross_pnl_pips, gross_pnl_currency,
                 commission, swap, net_pnl_currency, mae_pips, mfe_pips,
                 duration_minutes, r_multiple)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                trade.trade_id,
                trade.signal.signal_id,
                trade.signal.symbol,
                trade.signal.direction.value,
                trade.signal.timestamp.isoformat() if trade.signal.entry_price else trade.exit_time.isoformat(),
                str(trade.entry_price.value),
                trade.exit_time.isoformat() if trade.exit_time else None,
                str(trade.exit_price.value) if trade.exit_price else None,
                trade.exit_reason.value,
                str(trade.position_size.lots),
                str(trade.signal.entry_price.pips_from(trade.signal.stop_loss)) if trade.signal.entry_price and trade.signal.stop_loss else "0",
                str(trade.signal.entry_price.pips_from(trade.signal.take_profit)) if trade.signal.entry_price and trade.signal.take_profit else "0",
                str(trade.gross_pnl_pips),
                str(trade.gross_pnl_currency),
                str(trade.commission),
                str(trade.swap),
                str(trade.net_pnl_currency),
                str(trade.mae_pips),
                str(trade.mfe_pips),
                trade.duration_minutes,
                str(trade.r_multiple)
            ))

        # Update signal status
        self.update_signal_status(trade.signal.signal_id, "executed",
                                  trade.entry_price, trade.exit_time, trade.trade_id)

        logger.info(f"Recorded trade {trade.trade_id}: {trade.signal.symbol} P&L={trade.net_pnl_currency:.2f}")
        return trade.trade_id

    def add_journal_entry(self, entry: JournalEntry) -> int:
        """Add or update trading journal entry."""
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            cursor = conn.execute("""
                INSERT INTO journal
                (trade_id, symbol, direction, entry_time, entry_price,
                 exit_time, exit_price, exit_reason, position_size,
                 risk_pips, reward_pips, gross_pnl_pips, net_pnl_currency,
                 r_multiple, mae_pips, mfe_pips, duration_minutes,
                 regime, setup_quality, execution_quality,
                 psychology_notes, market_notes, lessons_learned,
                 created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(trade_id) DO UPDATE SET
                    exit_time=excluded.exit_time,
                    exit_price=excluded.exit_price,
                    exit_reason=excluded.exit_reason,
                    net_pnl_currency=excluded.net_pnl_currency,
                    r_multiple=excluded.r_multiple,
                    mae_pips=excluded.mae_pips,
                    mfe_pips=excluded.mfe_pips,
                    duration_minutes=excluded.duration_minutes,
                    regime=excluded.regime,
                    setup_quality=excluded.setup_quality,
                    execution_quality=excluded.execution_quality,
                    psychology_notes=excluded.psychology_notes,
                    market_notes=excluded.market_notes,
                    lessons_learned=excluded.lessons_learned,
                    updated_at=excluded.updated_at
            """, (
                entry.trade_id, entry.symbol, entry.direction,
                entry.entry_time.isoformat(), str(entry.entry_price),
                entry.exit_time.isoformat() if entry.exit_time else None,
                str(entry.exit_price) if entry.exit_price else None,
                entry.exit_reason, str(entry.position_size),
                str(entry.risk_pips), str(entry.reward_pips),
                str(entry.gross_pnl_pips), str(entry.net_pnl_currency),
                str(entry.r_multiple), str(entry.mae_pips), str(entry.mfe_pips),
                entry.duration_minutes, entry.regime,
                entry.setup_quality, entry.execution_quality,
                entry.psychology_notes, entry.market_notes, entry.lessons_learned,
                now, now
            ))
            return cursor.lastrowid

    def get_signals(self, symbol: Optional[str] = None,
                    status: Optional[str] = None,
                    start_date: Optional[datetime] = None,
                    end_date: Optional[datetime] = None,
                    limit: int = 1000) -> list[TrackedSignal]:
        """Query tracked signals with filters."""
        query = "SELECT * FROM signals WHERE 1=1"
        params = []

        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if status:
            query += " AND status = ?"
            params.append(status)
        if start_date:
            query += " AND timestamp >= ?"
            params.append(start_date.isoformat())
        if end_date:
            query += " AND timestamp <= ?"
            params.append(end_date.isoformat())

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()

        return [self._row_to_tracked_signal(row) for row in rows]

    def get_trades(self, symbol: Optional[str] = None,
                   start_date: Optional[datetime] = None,
                   end_date: Optional[datetime] = None,
                   limit: int = 1000) -> list[dict]:
        """Query completed trades."""
        query = "SELECT * FROM trades WHERE 1=1"
        params = []

        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if start_date:
            query += " AND entry_time >= ?"
            params.append(start_date.isoformat())
        if end_date:
            query += " AND entry_time <= ?"
            params.append(end_date.isoformat())

        query += " ORDER BY entry_time DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()
            return [dict(row) for row in rows]

    def get_performance_stats(self, symbol: Optional[str] = None,
                              start_date: Optional[datetime] = None,
                              end_date: Optional[datetime] = None) -> dict:
        """Calculate performance statistics from recorded trades."""
        trades = self.get_trades(symbol, start_date, end_date, limit=10000)

        if not trades:
            return {"error": "No trades found"}

        pnls = [Decimal(t["net_pnl_currency"]) for t in trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        r_multiples = [Decimal(t["r_multiple"]) for t in trades]

        return {
            "total_trades": len(trades),
            "wins": len(wins),
            "losses": len(losses),
            "win_rate": len(wins) / len(trades) if trades else 0,
            "avg_win": float(sum(wins) / len(wins)) if wins else 0,
            "avg_loss": float(sum(losses) / len(losses)) if losses else 0,
            "profit_factor": float(sum(wins) / abs(sum(losses))) if losses else float('inf'),
            "net_profit": float(sum(pnls)),
            "expectancy": float(sum(pnls) / len(pnls)),
            "avg_r_multiple": float(sum(r_multiples) / len(r_multiples)),
            "max_r_multiple": float(max(r_multiples)),
            "min_r_multiple": float(min(r_multiples)),
            "avg_mae_pips": float(sum(Decimal(t["mae_pips"]) for t in trades) / len(trades)),
            "avg_mfe_pips": float(sum(Decimal(t["mfe_pips"]) for t in trades) / len(trades)),
        }

    def export_journal_csv(self, output_path: Path) -> int:
        """Export journal entries to CSV for analysis."""
        import csv
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM journal ORDER BY entry_time").fetchall()

        if not rows:
            return 0

        fieldnames = rows[0].keys()
        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(dict(row))

        return len(rows)

    def _row_to_tracked_signal(self, row: sqlite3.Row) -> TrackedSignal:
        """Convert database row to TrackedSignal."""
        signal = ForexSignal(
            symbol=row["symbol"],
            direction=Direction(row["direction"]),
            strength=SignalStrength(row["strength"]),
            timestamp=datetime.fromisoformat(row["timestamp"]),
            source=row["source"],
            entry_price=PriceLevel(Decimal(row["entry_price"]), row["symbol"]) if row["entry_price"] else None,
            stop_loss=PriceLevel(Decimal(row["stop_loss"]), row["symbol"]) if row["stop_loss"] else None,
            take_profit=PriceLevel(Decimal(row["take_profit"]), row["symbol"]) if row["take_profit"] else None,
            signal_id=row["id"],
            raw_data=json.loads(row["raw_data"]) if row["raw_data"] else {}
        )
        return TrackedSignal(
            signal=signal,
            tracked_at=datetime.fromisoformat(row["tracked_at"]),
            status=row["status"],
            execution_price=PriceLevel(Decimal(row["execution_price"]), row["symbol"]) if row["execution_price"] else None,
            execution_time=datetime.fromisoformat(row["execution_time"]) if row["execution_time"] else None,
            trade_id=row["trade_id"],
            notes=row["notes"] or ""
        )


def create_tracker(db_path: Path = Path("./data/signals.db")) -> SignalTracker:
    return SignalTracker(db_path)