"""
Vectorized backtesting engine with realistic execution simulation.
Supports multiple signals, regime filtering, and comprehensive analytics.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Literal, Callable
import pandas as pd
import numpy as np
import logging

from .types import (
    ForexSignal, OHLCV, TradeResult, TradeStatus, PositionSize,
    PriceLevel, Direction, AccountState
)
from .config import get_config, BacktestConfig, SymbolSpec
from .risk import RiskManager, PositionSizer
from .regime import RegimeDetector, RegimeState

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class BacktestTrade:
    """Internal trade representation during backtest."""
    signal: ForexSignal
    entry_time: pd.Timestamp
    entry_price: PriceLevel
    stop_loss: PriceLevel
    take_profit: PriceLevel
    position_size: PositionSize
    max_holding_bars: int
    entry_bar_idx: int
    trade_id: str


@dataclass(frozen=True, slots=True)
class BacktestResult:
    """Complete backtest results with all metrics."""
    trades: list[TradeResult]
    equity_curve: pd.Series
    daily_returns: pd.Series
    metrics: dict
    config: BacktestConfig
    regime_states: list[RegimeState] = field(default_factory=list)

    def summary(self) -> dict:
        """Generate summary statistics."""
        if not self.trades:
            return {"error": "No trades executed"}

        pnls = [t.net_pnl_currency for t in self.trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]

        equity_final = self.equity_curve.iloc[-1] if len(self.equity_curve) > 0 else Decimal("0")
        equity_peak = self.equity_curve.cummax()
        drawdown = (self.equity_curve - equity_peak) / equity_peak
        max_dd = drawdown.min()

        return {
            "total_trades": len(self.trades),
            "wins": len(wins),
            "losses": len(losses),
            "win_rate": len(wins) / len(self.trades) if self.trades else 0,
            "avg_win": float(sum(wins) / len(wins)) if wins else 0,
            "avg_loss": float(sum(losses) / len(losses)) if losses else 0,
            "profit_factor": float(sum(wins) / abs(sum(losses))) if losses else float('inf'),
            "expectancy": float(sum(pnls) / len(pnls)) if pnls else 0,
            "net_profit": float(sum(pnls)),
            "max_drawdown_pct": float(max_dd * 100),
            "sharpe_ratio": self._calc_sharpe(),
            "sortino_ratio": self._calc_sortino(),
            "calmar_ratio": self._calc_calmar(max_dd),
            "avg_r_multiple": float(sum(t.r_multiple for t in self.trades) / len(self.trades)),
            "avg_mae_pips": float(sum(t.mae_pips for t in self.trades) / len(self.trades)),
            "avg_mfe_pips": float(sum(t.mfe_pips for t in self.trades) / len(self.trades)),
            "avg_duration_hours": float(sum(t.duration_minutes for t in self.trades) / len(self.trades) / 60),
        }

    def _calc_sharpe(self) -> float:
        if len(self.daily_returns) < 2:
            return 0.0
        return float(self.daily_returns.mean() / self.daily_returns.std() * np.sqrt(252))

    def _calc_sortino(self) -> float:
        if len(self.daily_returns) < 2:
            return 0.0
        downside = self.daily_returns[self.daily_returns < 0]
        if len(downside) == 0:
            return float('inf')
        return float(self.daily_returns.mean() / downside.std() * np.sqrt(252))

    def _calc_calmar(self, max_dd: Decimal) -> float:
        if max_dd == 0:
            return float('inf')
        annual_return = float(self.equity_curve.iloc[-1] / self.equity_curve.iloc[0] - 1) * 252 / len(self.daily_returns)
        return annual_return / float(abs(max_dd))


class BacktestEngine:
    """
    Event-driven backtest engine with realistic execution modeling.
    """

    def __init__(self, config: Optional[BacktestConfig] = None,
                 symbol_specs: Optional[dict[str, SymbolSpec]] = None,
                 risk_manager: Optional[RiskManager] = None,
                 regime_detector: Optional[RegimeDetector] = None):
        self.config = config or get_config().backtest
        self.symbol_specs = symbol_specs or get_config().symbols
        self.risk_manager = risk_manager or RiskManager()
        self.regime_detector = regime_detector or RegimeDetector()
        self.sizer = PositionSizer()

        # Account state
        self.equity = self.config.initial_equity
        self.balance = self.config.initial_equity
        self.open_trades: dict[str, BacktestTrade] = {}
        self.closed_trades: list[TradeResult] = []
        self.equity_curve: list[tuple[pd.Timestamp, Decimal]] = []
        self.daily_pnl: dict[str, Decimal] = {}

    def run(self, signals: list[ForexSignal], price_data: dict[str, list[OHLCV]]) -> BacktestResult:
        """
        Run backtest on signals with corresponding price data.
        signals: List of ForexSignal objects
        price_data: Dict mapping symbol -> list of OHLCV bars
        """
        logger.info(f"Starting backtest: {len(signals)} signals, {len(price_data)} symbols")

        # Prepare data
        self._prepare_data(price_data)

        # Detect regimes for each symbol
        self.regime_states = {}
        for symbol, bars in price_data.items():
            if len(bars) > 50:
                self.regime_states[symbol] = self.regime_detector.detect(bars)

        # Sort signals by timestamp
        signals_sorted = sorted(signals, key=lambda s: s.timestamp)

        # Process each signal
        for signal in signals_sorted:
            self._process_signal(signal)

        # Close any remaining open trades at end
        self._close_all_trades("End_of_backtest")

        # Build results
        return self._build_result()

    def _prepare_data(self, price_data: dict[str, list[OHLCV]]):
        """Convert price data to DataFrames for vectorized access."""
        self.price_dfs = {}
        self.bar_indices = {}  # Map timestamp -> bar index

        for symbol, bars in price_data.items():
            df = pd.DataFrame({
                "open": [float(b.open.value) for b in bars],
                "high": [float(b.high.value) for b in bars],
                "low": [float(b.low.value) for b in bars],
                "close": [float(b.close.value) for b in bars],
                "volume": [float(b.volume) for b in bars],
            }, index=pd.DatetimeIndex([b.timestamp for b in bars], tz=timezone.utc))

            self.price_dfs[symbol] = df
            self.bar_indices[symbol] = {ts: i for i, ts in enumerate(df.index)}

    def _process_signal(self, signal: ForexSignal):
        """Process a single signal: validate, size, and open trade."""
        df = self.price_dfs.get(signal.symbol)
        if df is None:
            logger.warning(f"No price data for {signal.symbol}, skipping signal")
            return

        # Find entry bar (first bar at or after signal timestamp)
        entry_idx = self._find_entry_bar(signal.symbol, signal.timestamp)
        if entry_idx is None or entry_idx >= len(df) - 1:
            logger.debug(f"No valid entry bar for {signal.signal_id} at {signal.timestamp}")
            return

        # Get entry price (next bar open for realistic execution)
        entry_bar_idx = entry_idx + 1
        if entry_bar_idx >= len(df):
            return

        entry_price = PriceLevel(Decimal(str(df.iloc[entry_bar_idx]["open"])), signal.symbol)

        # Apply slippage
        entry_price = self._apply_slippage(entry_price, signal.direction)

        # Create signal with actual entry price
        signal_with_entry = ForexSignal(
            symbol=signal.symbol,
            direction=signal.direction,
            strength=signal.strength,
            timestamp=signal.timestamp,
            source=signal.source,
            entry_price=entry_price,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
            signal_id=signal.signal_id,
            raw_data=signal.raw_data
        )

        # Regime filter
        if self.config.data_timeframe != "tick" and self.regime_states.get(signal.symbol):
            regime_state = self.regime_states[signal.symbol][entry_bar_idx]
            if not self.regime_detector.regime_aligned(signal.direction.value, regime_state.regime):
                logger.debug(f"Signal {signal.signal_id} filtered by regime: {regime_state.regime.value}")
                return

        # Risk validation
        account = AccountState(
            equity=self.equity,
            balance=self.balance,
            free_margin=self.equity - sum(t.position_size.margin_required for t in self.open_trades.values()),
            used_margin=sum(t.position_size.margin_required for t in self.open_trades.values()),
            margin_level=Decimal("1000") if self.equity > 0 else Decimal("0"),
            open_positions=len(self.open_trades),
            daily_pnl=self.daily_pnl.get(str(df.index[entry_bar_idx].date()), Decimal("0")),
            max_drawdown_pct=Decimal("0")  # Simplified
        )

        approved, reason, position_size = self.risk_manager.validate_signal(
            signal_with_entry, account, list(self.open_trades.values())
        )

        if not approved:
            logger.debug(f"Signal {signal.signal_id} rejected: {reason}")
            return

        # Open trade
        trade = BacktestTrade(
            signal=signal_with_entry,
            entry_time=df.index[entry_bar_idx],
            entry_price=entry_price,
            stop_loss=signal_with_entry.stop_loss,
            take_profit=signal_with_entry.take_profit,
            position_size=position_size,
            max_holding_bars=self._hours_to_bars(self.config.max_holding_hours, df),
            entry_bar_idx=entry_bar_idx,
            trade_id=signal.signal_id
        )

        self.open_trades[trade.trade_id] = trade
        logger.debug(f"Opened trade {trade.trade_id}: {signal.symbol} {signal.direction.value} @ {entry_price.value}")

    def _find_entry_bar(self, symbol: str, timestamp: datetime) -> Optional[int]:
        """Find the first bar index at or after the signal timestamp."""
        indices = self.bar_indices.get(symbol, {})
        # Find closest timestamp >= signal timestamp
        for ts, idx in indices.items():
            if ts >= timestamp:
                return idx
        return None

    def _apply_slippage(self, price: PriceLevel, direction: Direction) -> PriceLevel:
        """Apply slippage model."""
        if self.config.slippage_model == "none":
            return price

        slippage_pips = Decimal(str(self.config.backtest.__dict__.get("slippage_pips", 0.5)))
        if direction == Direction.BUY:
            return price.add_pips(slippage_pips)
        else:
            return price.subtract_pips(slippage_pips)

    def _hours_to_bars(self, hours: int, df: pd.DataFrame) -> int:
        """Convert hours to number of bars based on data frequency."""
        if len(df) < 2:
            return hours * 4  # Default assumption
        freq_minutes = (df.index[1] - df.index[0]).total_seconds() / 60
        return max(1, int(hours * 60 / freq_minutes))

    def _close_all_trades(self, reason: str):
        """Force close all open trades."""
        for trade_id in list(self.open_trades.keys()):
            self._close_trade(trade_id, reason)

    def _close_trade(self, trade_id: str, exit_reason: str):
        """Close a specific trade."""
        trade = self.open_trades.pop(trade_id, None)
        if not trade:
            return

        df = self.price_dfs[trade.signal.symbol]
        exit_bar_idx = min(trade.entry_bar_idx + trade.max_holding_bars, len(df) - 1)

        # Simulate trade bar by bar for realistic exit
        exit_price, exit_time, exit_status, mae, mfe = self._simulate_trade_exit(trade, df, exit_bar_idx)

        # Calculate P&L
        gross_pnl_pips = trade.entry_price.pips_from(exit_price)
        if trade.signal.direction == Direction.SELL:
            gross_pnl_pips = -gross_pnl_pips

        pip_value = trade.position_size.pip_value
        gross_pnl_currency = gross_pnl_pips * pip_value

        # Commission
        spec = self.symbol_specs.get(trade.signal.symbol)
        commission = spec.commission_per_lot * trade.position_size.lots if spec else Decimal("0")

        # Swap (simplified)
        swap = Decimal("0")
        if exit_bar_idx > trade.entry_bar_idx:
            days_held = (exit_time - trade.entry_time).days
            if days_held > 0:
                swap_rate = spec.swap_long if trade.signal.is_buy else spec.swap_short if spec else Decimal("0")
                swap = swap_rate * trade.position_size.lots * Decimal(str(days_held))

        net_pnl = gross_pnl_currency - commission + swap

        # Update equity
        self.equity += net_pnl
        self.balance += net_pnl
        date_key = str(exit_time.date())
        self.daily_pnl[date_key] = self.daily_pnl.get(date_key, Decimal("0")) + net_pnl

        # Record trade
        result = TradeResult(
            signal=trade.signal,
            entry_price=trade.entry_price,
            exit_price=exit_price,
            exit_time=exit_time.to_pydatetime() if hasattr(exit_time, 'to_pydatetime') else exit_time,
            exit_reason=TradeStatus(exit_status),
            position_size=trade.position_size,
            gross_pnl_pips=gross_pnl_pips,
            gross_pnl_currency=gross_pnl_currency.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            commission=commission.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            swap=swap.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            net_pnl_currency=net_pnl.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            mae_pips=mae,
            mfe_pips=mfe,
            duration_minutes=int((exit_time - trade.entry_time).total_seconds() / 60),
            trade_id=trade_id
        )

        self.closed_trades.append(result)
        logger.debug(f"Closed trade {trade_id}: {exit_status} @ {exit_price.value}, P&L: {net_pnl:.2f}")

    def _simulate_trade_exit(self, trade: BacktestTrade, df: pd.DataFrame, max_bar_idx: int) -> tuple[PriceLevel, pd.Timestamp, str, Decimal, Decimal]:
        """
        Simulate trade exit bar-by-bar.
        Returns: (exit_price, exit_time, exit_status, mae_pips, mfe_pips)
        """
        entry_price = trade.entry_price.value
        sl_price = trade.stop_loss.value
        tp_price = trade.take_profit.value
        is_buy = trade.signal.is_buy

        max_favorable = Decimal("0")
        max_adverse = Decimal("0")

        for i in range(trade.entry_bar_idx + 1, max_bar_idx + 1):
            high = Decimal(str(df.iloc[i]["high"]))
            low = Decimal(str(df.iloc[i]["low"]))
            close = Decimal(str(df.iloc[i]["close"]))

            if is_buy:
                # Check stop loss (low hits SL)
                if low <= sl_price:
                    return PriceLevel(sl_price, trade.signal.symbol), df.index[i], "Closed_StopLoss", max_adverse, max_favorable
                # Check take profit (high hits TP)
                if high >= tp_price:
                    return PriceLevel(tp_price, trade.signal.symbol), df.index[i], "Closed_TakeProfit", max_adverse, max_favorable

                # Track MAE/MFE
                favorable = (high - entry_price) / (Decimal("0.0001") if "JPY" not in trade.signal.symbol else Decimal("0.01"))
                adverse = (entry_price - low) / (Decimal("0.0001") if "JPY" not in trade.signal.symbol else Decimal("0.01"))
            else:
                # SELL trade
                if high >= sl_price:
                    return PriceLevel(sl_price, trade.signal.symbol), df.index[i], "Closed_StopLoss", max_adverse, max_favorable
                if low <= tp_price:
                    return PriceLevel(tp_price, trade.signal.symbol), df.index[i], "Closed_TakeProfit", max_adverse, max_favorable

                favorable = (entry_price - low) / (Decimal("0.0001") if "JPY" not in trade.signal.symbol else Decimal("0.01"))
                adverse = (high - entry_price) / (Decimal("0.0001") if "JPY" not in trade.signal.symbol else Decimal("0.01"))

            max_favorable = max(max_favorable, favorable)
            max_adverse = max(max_adverse, adverse)

        # Time exit
        exit_price = PriceLevel(Decimal(str(df.iloc[max_bar_idx]["close"])), trade.signal.symbol)
        return exit_price, df.index[max_bar_idx], "Closed_TimeExit", max_adverse, max_favorable

    def _build_result(self) -> BacktestResult:
        """Build final backtest result object."""
        # Equity curve
        equity_data = [(ts, float(eq)) for ts, eq in self.equity_curve]
        if not equity_data:
            equity_curve = pd.Series(dtype=float)
        else:
            equity_curve = pd.Series([eq for _, eq in equity_data], index=[ts for ts, _ in equity_data])

        # Daily returns
        if len(self.daily_pnl) > 0:
            daily_series = pd.Series(self.daily_pnl)
            daily_returns = daily_series / self.config.initial_equity
        else:
            daily_returns = pd.Series(dtype=float)

        # Flatten regime states
        all_regimes = []
        for symbol, states in self.regime_states.items():
            all_regimes.extend(states)

        return BacktestResult(
            trades=self.closed_trades,
            equity_curve=equity_curve,
            daily_returns=daily_returns,
            metrics={},  # Will be populated by summary()
            config=self.config,
            regime_states=all_regimes
        )


def run_backtest(signals: list[ForexSignal], price_data: dict[str, list[OHLCV]],
                 config: Optional[BacktestConfig] = None) -> BacktestResult:
    """Convenience function to run a backtest."""
    engine = BacktestEngine(config=config)
    return engine.run(signals, price_data)