"""
Signal parsing and normalization for various sources.
Includes XTrend Speed specific parser.
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from typing import Optional, Literal
import re
import json
import logging

from .types import ForexSignal, Direction, SignalStrength, PriceLevel

logger = logging.getLogger(__name__)


class SignalParser:
    """Base signal parser."""

    def parse(self, raw_data: dict | str) -> list[ForexSignal]:
        raise NotImplementedError


class XTrendSpeedParser(SignalParser):
    """
    Parser for XTrend Speed signal format.
    Handles the table format from their web interface.
    """

    # Symbol normalization map
    SYMBOL_MAP = {
        "AUDUSD": "AUDUSD",
        "EURUSD": "EURUSD",
        "USDJPY": "USDJPY",
        "GBPUSD": "GBPUSD",
        "NZDUSD": "NZDUSD",
        "USDCAD": "USDCAD",
        "USDCHF": "USDCHF",
        "AUDJPY": "AUDJPY",
        "EURGBP": "EURGBP",
        "EURJPY": "EURJPY",
        "GBPJPY": "GBPJPY",
        "CHFJPY": "CHFJPY",
        "CADJPY": "CADJPY",
        "EURAUD": "EURAUD",
        "EURCAD": "EURCAD",
        "EURNZD": "EURNZD",
        "GBPAUD": "GBPAUD",
        "GBPCAD": "GBPCAD",
        "GBPCHF": "GBPCHF",
        "AUDCHF": "AUDCHF",
        "AUDCAD": "AUDCAD",
        "AUDNZD": "AUDNZD",
        "CADCHF": "CADCHF",
        "NZDCAD": "NZDCAD",
        "NZDCHF": "NZDCHF",
        "NZDJPY": "NZDJPY",
    }

    STRENGTH_MAP = {
        "strong": SignalStrength.STRONG,
        "general": SignalStrength.GENERAL,
        "weak": SignalStrength.WEAK,
        "high": SignalStrength.STRONG,
        "medium": SignalStrength.GENERAL,
        "low": SignalStrength.WEAK,
    }

    def parse(self, raw_data: dict | str) -> list[ForexSignal]:
        """Parse XTrend Speed signal data."""
        if isinstance(raw_data, str):
            # Try to parse as JSON first
            try:
                raw_data = json.loads(raw_data)
            except json.JSONDecodeError:
                # Parse as text (HTML/table format)
                return self._parse_text(raw_data)

        if isinstance(raw_data, dict):
            return self._parse_dict(raw_data)
        elif isinstance(raw_data, list):
            return self._parse_list(raw_data)

        return []

    def _parse_text(self, text: str) -> list[ForexSignal]:
        """Parse text/table format from web scraping."""
        signals = []

        # Pattern: Symbol followed by Direction, Time, Strength
        # Example: "AUDUSD\n\nAUDUSD\n\nSell\n01:08\nGeneral"
        lines = [line.strip() for line in text.split('\n') if line.strip()]

        i = 0
        while i < len(lines):
            # Look for symbol pattern (6-7 chars, all caps)
            if re.match(r'^[A-Z]{6,7}$', lines[i]):
                symbol = lines[i]
                i += 1

                # Skip duplicate symbol line if present
                if i < len(lines) and lines[i] == symbol:
                    i += 1

                # Next should be direction
                if i < len(lines) and lines[i].lower() in ("buy", "sell"):
                    direction = Direction.from_string(lines[i])
                    i += 1

                    # Next should be time
                    if i < len(lines) and re.match(r'^\d{1,2}:\d{2}$', lines[i]):
                        time_str = lines[i]
                        i += 1

                        # Next should be strength
                        if i < len(lines) and lines[i].lower() in ("strong", "general", "weak", "high", "medium", "low"):
                            strength = self.STRENGTH_MAP.get(lines[i].lower(), SignalStrength.GENERAL)
                            i += 1

                            # Parse timestamp (assume today)
                            now = datetime.now(timezone.utc)
                            try:
                                hour, minute = map(int, time_str.split(':'))
                                timestamp = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                                # If timestamp is in future, assume yesterday
                                if timestamp > now:
                                    timestamp -= timedelta(days=1)
                            except ValueError:
                                timestamp = now

                            signal = ForexSignal(
                                symbol=self.SYMBOL_MAP.get(symbol, symbol),
                                direction=direction,
                                strength=strength,
                                timestamp=timestamp,
                                source="XTrendSpeed",
                                raw_data={"original_symbol": symbol, "time_str": time_str}
                            )
                            signals.append(signal)
                            continue
            i += 1

        logger.info(f"Parsed {len(signals)} signals from XTrend Speed text")
        return signals

    def _parse_dict(self, data: dict) -> list[ForexSignal]:
        """Parse dictionary format (API response)."""
        signals = []

        # Handle various possible structures
        items = data.get("data", data.get("signals", data.get("items", [data])))

        if isinstance(items, dict):
            items = [items]

        for item in items:
            try:
                signal = self._parse_signal_item(item)
                if signal:
                    signals.append(signal)
            except Exception as e:
                logger.warning(f"Failed to parse signal item: {e}")

        return signals

    def _parse_list(self, data: list) -> list[ForexSignal]:
        """Parse list of signal objects."""
        signals = []
        for item in data:
            try:
                signal = self._parse_signal_item(item)
                if signal:
                    signals.append(signal)
            except Exception as e:
                logger.warning(f"Failed to parse signal item: {e}")
        return signals

    def _parse_signal_item(self, item: dict) -> Optional[ForexSignal]:
        """Parse a single signal item from dict."""
        # Extract fields with flexible key names
        symbol = (item.get("symbol") or item.get("pair") or item.get("instrument") or "").upper()
        direction_str = (item.get("direction") or item.get("side") or item.get("signal") or "").strip()
        strength_str = (item.get("strength") or item.get("confidence") or item.get("type") or "General").strip()
        time_str = (item.get("time") or item.get("timestamp") or item.get("updateTime") or "")

        if not symbol or not direction_str:
            return None

        # Normalize symbol
        symbol = self.SYMBOL_MAP.get(symbol, symbol.replace("/", "").replace("-", ""))

        # Parse direction
        try:
            direction = Direction.from_string(direction_str)
        except ValueError:
            return None

        # Parse strength
        strength = self.STRENGTH_MAP.get(strength_str.lower(), SignalStrength.GENERAL)

        # Parse timestamp
        timestamp = self._parse_timestamp(time_str)

        return ForexSignal(
            symbol=symbol,
            direction=direction,
            strength=strength,
            timestamp=timestamp,
            source="XTrendSpeed",
            raw_data=item
        )

    def _parse_timestamp(self, time_str: str) -> datetime:
        """Parse various timestamp formats."""
        now = datetime.now(timezone.utc)

        if not time_str:
            return now

        # Try ISO format
        try:
            return datetime.fromisoformat(time_str.replace('Z', '+00:00'))
        except ValueError:
            pass

        # Try HH:MM format (assume today)
        try:
            hour, minute = map(int, time_str.split(':')[:2])
            timestamp = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if timestamp > now:
                timestamp -= timedelta(days=1)
            return timestamp
        except ValueError:
            pass

        # Try Unix timestamp
        try:
            return datetime.fromtimestamp(int(time_str), tz=timezone.utc)
        except ValueError:
            pass

        return now


class GenericSignalParser(SignalParser):
    """Generic parser for common signal formats."""

    def parse(self, raw_data: dict | str) -> list[ForexSignal]:
        if isinstance(raw_data, str):
            try:
                raw_data = json.loads(raw_data)
            except json.JSONDecodeError:
                return []

        if isinstance(raw_data, list):
            return self._parse_list(raw_data)
        elif isinstance(raw_data, dict):
            return self._parse_dict(raw_data)
        return []

    def _parse_list(self, data: list) -> list[ForexSignal]:
        signals = []
        for item in data:
            signal = self._parse_item(item)
            if signal:
                signals.append(signal)
        return signals

    def _parse_dict(self, data: dict) -> list[ForexSignal]:
        return self._parse_list(data.get("signals", data.get("data", [data])))

    def _parse_item(self, item: dict) -> Optional[ForexSignal]:
        try:
            return ForexSignal(
                symbol=item.get("symbol", "").upper().replace("/", ""),
                direction=Direction.from_string(item.get("direction", "Buy")),
                strength=SignalStrength.from_string(item.get("strength", "General")),
                timestamp=datetime.fromisoformat(item.get("timestamp", datetime.now(timezone.utc).isoformat())),
                source=item.get("source", "Generic"),
                entry_price=PriceLevel(Decimal(str(item["entry"])), item.get("symbol", "")) if item.get("entry") else None,
                stop_loss=PriceLevel(Decimal(str(item["sl"])), item.get("symbol", "")) if item.get("sl") else None,
                take_profit=PriceLevel(Decimal(str(item["tp"])), item.get("symbol", "")) if item.get("tp") else None,
                raw_data=item
            )
        except Exception:
            return None


def create_parser(source: str = "xtrend") -> SignalParser:
    """Factory function to create appropriate parser."""
    parsers = {
        "xtrend": XTrendSpeedParser(),
        "xtrendspeed": XTrendSpeedParser(),
        "generic": GenericSignalParser(),
    }
    return parsers.get(source.lower(), GenericSignalParser())