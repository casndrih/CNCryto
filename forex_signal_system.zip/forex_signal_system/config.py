"""
Configuration management with validation.
All parameters explicitly typed and validated.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Optional
import json
import os


@dataclass(frozen=True, slots=True)
class SymbolSpec:
    """Contract specification for a forex pair."""
    symbol: str
    pip_size: Decimal
    pip_value_per_lot: Decimal  # In account currency per pip per standard lot
    margin_rate: Decimal  # Margin requirement as fraction (e.g., 0.0333 for 30:1)
    min_lot: Decimal = Decimal("0.01")
    max_lot: Decimal = Decimal("100")
    lot_step: Decimal = Decimal("0.01")
    commission_per_lot: Decimal = Decimal("0")  # Round-trip commission
    swap_long: Decimal = Decimal("0")  # Swap points per lot per night
    swap_short: Decimal = Decimal("0")
    trading_sessions: tuple[str, ...] = ("Sydney", "Tokyo", "London", "New York")

    # Major pair defaults
    @classmethod
    def defaults(cls) -> dict[str, SymbolSpec]:
        return {
            "EURUSD": cls("EURUSD", Decimal("0.0001"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.5"), swap_short=Decimal("0.2")),
            "GBPUSD": cls("GBPUSD", Decimal("0.0001"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.8"), swap_short=Decimal("0.3")),
            "USDJPY": cls("USDJPY", Decimal("0.01"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("0.5"), swap_short=Decimal("-1.2")),
            "USDCHF": cls("USDCHF", Decimal("0.0001"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("1.2"), swap_short=Decimal("-2.5")),
            "AUDUSD": cls("AUDUSD", Decimal("0.0001"), Decimal("10"), Decimal("0.05"), swap_long=Decimal("-0.3"), swap_short=Decimal("-0.1")),
            "USDCAD": cls("USDCAD", Decimal("0.0001"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.2"), swap_short=Decimal("-0.5")),
            "NZDUSD": cls("NZDUSD", Decimal("0.0001"), Decimal("10"), Decimal("0.05"), swap_long=Decimal("-0.4"), swap_short=Decimal("0.1")),
            "EURGBP": cls("EURGBP", Decimal("0.0001"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.6"), swap_short=Decimal("0.2")),
            "EURJPY": cls("EURJPY", Decimal("0.01"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.8"), swap_short=Decimal("0.3")),
            "AUDJPY": cls("AUDJPY", Decimal("0.01"), Decimal("10"), Decimal("0.0333"), swap_long=Decimal("-0.5"), swap_short=Decimal("0.1")),
        }

    def get(self, symbol: str) -> SymbolSpec:
        """Get spec with fallback to generic."""
        return self.defaults().get(symbol.upper(), SymbolSpec(
            symbol=symbol.upper(),
            pip_size=Decimal("0.0001") if "JPY" not in symbol.upper() else Decimal("0.01"),
            pip_value_per_lot=Decimal("10"),
            margin_rate=Decimal("0.05"),
        ))


@dataclass(frozen=True, slots=True)
class RiskConfig:
    """Risk management parameters."""
    risk_per_trade_pct: Decimal = Decimal("0.01")      # 1% per trade
    max_daily_loss_pct: Decimal = Decimal("0.03")      # 3% daily stop
    max_drawdown_pct: Decimal = Decimal("0.08")        # 8% max drawdown halt
    max_concurrent_positions: int = 5
    max_correlated_exposure: int = 3                   # Max positions in same currency
    min_risk_reward: Decimal = Decimal("1.5")          # Minimum R:R to take trade
    max_slippage_pips: Decimal = Decimal("1.5")        # Max acceptable slippage
    max_spread_pips: Decimal = Decimal("3.0")          # Max spread to enter
    position_sizing_method: Literal["fixed_fractional", "kelly", "volatility"] = "fixed_fractional"
    kelly_fraction: Decimal = Decimal("0.25")          # Fraction of Kelly criterion


@dataclass(frozen=True, slots=True)
class BacktestConfig:
    """Backtesting engine configuration."""
    start_date: str = "2024-01-01"
    end_date: str = "2024-12-31"
    initial_equity: Decimal = Decimal("10000")
    account_currency: str = "USD"
    spread_model: Literal["fixed", "dynamic", "historical"] = "dynamic"
    slippage_model: Literal["none", "fixed", "volume_weighted"] = "fixed"
    commission_model: Literal["none", "per_lot", "percentage"] = "per_lot"
    data_timeframe: str = "M15"  # M1, M5, M15, M30, H1, H4, D1
    max_holding_hours: int = 48
    weekend_handling: Literal["close_friday", "hold", "close_sunday"] = "close_friday"
    news_filter: bool = True
    news_window_minutes: int = 30


@dataclass(frozen=True, slots=True)
class RegimeConfig:
    """Market regime detection parameters."""
    adx_period: int = 14
    adx_trend_threshold: Decimal = Decimal("25")
    ma_fast_period: int = 20
    ma_slow_period: int = 50
    ma_slope_lookback: int = 5
    atr_period: int = 14
    volatility_lookback: int = 200
    volatility_high_percentile: Decimal = Decimal("0.8")
    volatility_low_percentile: Decimal = Decimal("0.2")
    regime_lookback: int = 200


@dataclass(frozen=True, slots=True)
class DataConfig:
    """Data source configuration."""
    provider: Literal["yahoo", "oanda", "dukascopy", "csv", "mt5"] = "yahoo"
    cache_dir: Path = Path("./data_cache")
    update_on_start: bool = True
    validate_data: bool = True
    fill_gaps: bool = True
    max_gap_minutes: int = 60


@dataclass(frozen=True, slots=True)
class SystemConfig:
    """Master configuration container."""
    risk: RiskConfig = field(default_factory=RiskConfig)
    backtest: BacktestConfig = field(default_factory=BacktestConfig)
    regime: RegimeConfig = field(default_factory=RegimeConfig)
    data: DataConfig = field(default_factory=DataConfig)
    symbols: dict[str, SymbolSpec] = field(default_factory=SymbolSpec.defaults)
    log_level: str = "INFO"
    log_file: Optional[Path] = Path("./logs/system.log")
    results_dir: Path = Path("./results")

    def to_json(self, path: Path | str) -> None:
        """Serialize to JSON (excludes non-serializable fields)."""
        path = Path(path)
        def dc_to_dict(obj):
            """Convert dataclass to dict, works with slots=True."""
            if hasattr(obj, '__dataclass_fields__'):
                return {f: getattr(obj, f) for f in obj.__dataclass_fields__}
            return obj

        data = {
            "risk": dc_to_dict(self.risk),
            "backtest": dc_to_dict(self.backtest),
            "regime": dc_to_dict(self.regime),
            "data": {k: str(v) if isinstance(v, Path) else v for k, v in dc_to_dict(self.data).items()},
            "symbols": {k: dc_to_dict(v) for k, v in self.symbols.items()},
            "log_level": self.log_level,
            "log_file": str(self.log_file) if self.log_file else None,
            "results_dir": str(self.results_dir),
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, default=str))

    @classmethod
    def from_json(cls, path: Path) -> SystemConfig:
        """Load from JSON file."""
        data = json.loads(path.read_text())
        # Reconstruct nested configs
        return cls(
            risk=RiskConfig(**data.get("risk", {})),
            backtest=BacktestConfig(**data.get("backtest", {})),
            regime=RegimeConfig(**data.get("regime", {})),
            data=DataConfig(**{k: Path(v) if k.endswith("_dir") or k.endswith("_file") else v
                              for k, v in data.get("data", {}).items()}),
            symbols={k: SymbolSpec(**v) for k, v in data.get("symbols", {}).items()},
            log_level=data.get("log_level", "INFO"),
            log_file=Path(data["log_file"]) if data.get("log_file") else None,
            results_dir=Path(data.get("results_dir", "./results")),
        )

    @classmethod
    def default(cls) -> SystemConfig:
        """Create default configuration."""
        config = cls()
        # Ensure directories exist
        config.data.cache_dir.mkdir(parents=True, exist_ok=True)
        config.results_dir.mkdir(parents=True, exist_ok=True)
        if config.log_file:
            config.log_file.parent.mkdir(parents=True, exist_ok=True)
        return config


# Global config instance
_config: Optional[SystemConfig] = None


def get_config() -> SystemConfig:
    """Get global config instance (singleton)."""
    global _config
    if _config is None:
        _config = SystemConfig.default()
    return _config


def set_config(config: SystemConfig) -> None:
    """Set global config instance."""
    global _config
    _config = config