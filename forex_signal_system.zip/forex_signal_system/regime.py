"""
Market regime detection using multiple technical indicators.
Vectorized implementation for performance.
"""

from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Literal
import numpy as np
import pandas as pd

from .types import MarketRegime, OHLCV
from .config import get_config, RegimeConfig


@dataclass(frozen=True, slots=True)
class RegimeState:
    """Current market regime with supporting metrics."""
    regime: MarketRegime
    adx: float
    adx_trending: bool
    ma_slope: float
    atr_pct: float
    vol_percentile: float
    trend_strength: float  # 0-1 normalized
    confidence: float      # 0-1 regime classification confidence
    timestamp: pd.Timestamp

    def to_dict(self) -> dict:
        return {
            "regime": self.regime.value,
            "adx": round(self.adx, 2),
            "adx_trending": self.adx_trending,
            "ma_slope": round(self.ma_slope, 6),
            "atr_pct": round(self.atr_pct, 6),
            "vol_percentile": round(self.vol_percentile, 3),
            "trend_strength": round(self.trend_strength, 3),
            "confidence": round(self.confidence, 3),
            "timestamp": self.timestamp.isoformat(),
        }


class RegimeDetector:
    """
    Multi-factor regime detection using:
    - ADX for trend strength
    - MA slope for trend direction
    - ATR percentile for volatility regime
    """

    def __init__(self, config: Optional[RegimeConfig] = None):
        self.config = config or get_config().regime

    def calculate_adx(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """Calculate Average Directional Index (ADX)."""
        high = df["high"]
        low = df["low"]
        close = df["close"]

        # True Range
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        # Directional Movement
        up_move = high - high.shift(1)
        down_move = low.shift(1) - low

        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)

        # Smoothed averages (Wilder's smoothing)
        atr = tr.ewm(alpha=1/period, adjust=False).mean()
        plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1/period, adjust=False).mean() / atr
        minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1/period, adjust=False).mean() / atr

        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.ewm(alpha=1/period, adjust=False).mean()

        return adx

    def calculate_ma_slope(self, df: pd.DataFrame, fast: int = 20, slow: int = 50, lookback: int = 5) -> pd.Series:
        """Calculate moving average slope (rate of change)."""
        ma_fast = df["close"].rolling(fast).mean()
        ma_slow = df["close"].rolling(slow).mean()

        # Slope as percentage change over lookback periods
        slope = (ma_fast - ma_fast.shift(lookback)) / ma_fast.shift(lookback)
        return slope

    def calculate_atr_pct(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """Calculate ATR as percentage of price."""
        high = df["high"]
        low = df["low"]
        close = df["close"]

        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        atr = tr.ewm(alpha=1/period, adjust=False).mean()
        return atr / close

    def detect(self, ohlcv_list: list[OHLCV]) -> list[RegimeState]:
        """
        Detect regime for each bar in the series.
        Returns RegimeState for each bar (NaN for warmup period).
        """
        if len(ohlcv_list) < max(self.config.adx_period, self.config.ma_slow_period, self.config.atr_period) + 10:
            raise ValueError(f"Insufficient data for regime detection. Need at least {self.config.ma_slow_period + 10} bars.")

        df = self._to_dataframe(ohlcv_list)

        # Calculate indicators
        adx = self.calculate_adx(df, self.config.adx_period)
        ma_slope = self.calculate_ma_slope(df, self.config.ma_fast_period, self.config.ma_slow_period, self.config.ma_slope_lookback)
        atr_pct = self.calculate_atr_pct(df, self.config.atr_period)

        # Volatility percentile (rolling)
        vol_percentile = atr_pct.rolling(self.config.volatility_lookback).rank(pct=True)

        # Trend strength (normalized ADX)
        trend_strength = (adx / 50).clip(0, 1)  # ADX > 50 is very strong

        # Classify each bar
        states = []
        for i in range(len(df)):
            if pd.isna(adx.iloc[i]) or pd.isna(ma_slope.iloc[i]) or pd.isna(vol_percentile.iloc[i]):
                states.append(RegimeState(
                    regime=MarketRegime.UNKNOWN,
                    adx=float(adx.iloc[i]) if not pd.isna(adx.iloc[i]) else 0,
                    adx_trending=False,
                    ma_slope=float(ma_slope.iloc[i]) if not pd.isna(ma_slope.iloc[i]) else 0,
                    atr_pct=float(atr_pct.iloc[i]) if not pd.isna(atr_pct.iloc[i]) else 0,
                    vol_percentile=float(vol_percentile.iloc[i]) if not pd.isna(vol_percentile.iloc[i]) else 0.5,
                    trend_strength=0,
                    confidence=0,
                    timestamp=df.index[i]
                ))
                continue

            adx_val = float(adx.iloc[i])
            slope_val = float(ma_slope.iloc[i])
            vol_pct = float(vol_percentile.iloc[i])
            trend_str = float(trend_strength.iloc[i])

            # Regime classification logic
            is_trending = adx_val > float(self.config.adx_trend_threshold)
            is_high_vol = vol_pct > float(self.config.volatility_high_percentile)
            is_low_vol = vol_pct < float(self.config.volatility_low_percentile)

            if is_high_vol:
                regime = MarketRegime.VOLATILE
                confidence = min(vol_pct / float(self.config.volatility_high_percentile), 1.0)
            elif is_trending and slope_val > 0:
                regime = MarketRegime.TRENDING_UP
                confidence = min(trend_str * (1 + abs(slope_val) * 100), 1.0)
            elif is_trending and slope_val < 0:
                regime = MarketRegime.TRENDING_DOWN
                confidence = min(trend_str * (1 + abs(slope_val) * 100), 1.0)
            else:
                regime = MarketRegime.RANGING
                confidence = 1 - trend_str  # High confidence when ADX low

            states.append(RegimeState(
                regime=regime,
                adx=adx_val,
                adx_trending=is_trending,
                ma_slope=slope_val,
                atr_pct=float(atr_pct.iloc[i]),
                vol_percentile=vol_pct,
                trend_strength=trend_str,
                confidence=confidence,
                timestamp=df.index[i]
            ))

        return states

    def current_regime(self, ohlcv_list: list[OHLCV]) -> RegimeState:
        """Get regime for the most recent bar."""
        states = self.detect(ohlcv_list)
        return states[-1]

    def regime_aligned(self, direction: str, regime: MarketRegime) -> bool:
        """Check if trade direction aligns with regime."""
        if direction.upper() in ("BUY", "LONG"):
            return regime in (MarketRegime.TRENDING_UP, MarketRegime.RANGING)
        if direction.upper() in ("SELL", "SHORT"):
            return regime in (MarketRegime.TRENDING_DOWN, MarketRegime.RANGING)
        return False

    def _to_dataframe(self, ohlcv_list: list[OHLCV]) -> pd.DataFrame:
        data = {
            "open": [float(c.open.value) for c in ohlcv_list],
            "high": [float(c.high.value) for c in ohlcv_list],
            "low": [float(c.low.value) for c in ohlcv_list],
            "close": [float(c.close.value) for c in ohlcv_list],
            "volume": [float(c.volume) for c in ohlcv_list],
        }
        index = pd.DatetimeIndex([c.timestamp for c in ohlcv_list], tz=ohlcv_list[0].timestamp.tzinfo or None)
        return pd.DataFrame(data, index=index)


def create_regime_detector(config: Optional[RegimeConfig] = None) -> RegimeDetector:
    return RegimeDetector(config)