"""
Forex Signal Analysis & Backtesting System
Precision-engineered for signal validation, regime-aware backtesting, and risk-managed execution.
"""

__version__ = "1.0.0"
__author__ = "Forex Signal System"