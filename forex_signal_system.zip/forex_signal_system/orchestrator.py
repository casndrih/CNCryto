"""
Main orchestration module: ties together data, signals, regime, risk, backtest, and tracking.
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Optional, Literal
import logging
import asyncio

from .types import ForexSignal, OHLCV, AccountState
from .config import SystemConfig, get_config, set_config
from .data_provider import DataManager, create_data_manager
from .signal_parser import create_parser, XTrendSpeedParser
from .regime import RegimeDetector, create_regime_detector
from .risk import RiskManager, create_risk_manager
from .backtest import BacktestEngine, run_backtest, BacktestResult
from .tracker import SignalTracker, create_tracker, TrackedSignal, JournalEntry

logger = logging.getLogger(__name__)


@dataclass
class SystemState:
    """Current system state snapshot."""
    account: AccountState
    open_signals: list[TrackedSignal]
    open_trades: int
    current_regimes: dict[str, str]
    last_update: datetime


class ForexSignalSystem:
    """
    Main system orchestrator for signal analysis, backtesting, and paper/live trading.
    """

    def __init__(self, config: Optional[SystemConfig] = None):
        self.config = config or get_config()
        set_config(self.config)

        # Initialize components
        self.data_manager = create_data_manager(self.config.data)
        self.parser = create_parser("xtrend")
        self.regime_detector = create_regime_detector(self.config.regime)
        self.risk_manager = create_risk_manager(self.config.risk, self.config.symbols)
        self.tracker = create_tracker(Path(self.config.results_dir) / "signals.db")

        # State
        self._account_state = AccountState(
            equity=self.config.backtest.initial_equity,
            balance=self.config.backtest.initial_equity,
            free_margin=self.config.backtest.initial_equity,
            used_margin=Decimal("0"),
            margin_level=Decimal("1000"),
            open_positions=0,
            daily_pnl=Decimal("0"),
            max_drawdown_pct=Decimal("0"),
            currency=self.config.backtest.account_currency
        )

    async def fetch_live_signals(self) -> list[ForexSignal]:
        """Fetch and parse live signals from XTrend Speed."""
        # In production, this would use web_browser or HTTP client
        # For now, return the signals we already scraped
        logger.info("Fetching live signals from XTrend Speed...")
        # This would be implemented with actual HTTP fetch
        return []

    def load_signals_from_text(self, text: str) -> list[ForexSignal]:
        """Parse signals from raw text (e.g., scraped content)."""
        signals = self.parser.parse(text)
        logger.info(f"Parsed {len(signals)} signals from text")
        return signals

    def load_signals_from_file(self, file_path: Path) -> list[ForexSignal]:
        """Load signals from JSON file."""
        import json
        with open(file_path) as f:
            data = json.load(f)
        return self.parser.parse(data)

    def track_signals(self, signals: list[ForexSignal], notes: str = "") -> list[str]:
        """Record signals for tracking."""
        ids = []
        for signal in signals:
            signal_id = self.tracker.track_signal(signal, notes)
            ids.append(signal_id)
        return ids

    def fetch_price_data(self, symbols: list[str], timeframe: str,
                         start: datetime, end: datetime) -> dict[str, list[OHLCV]]:
        """Fetch historical price data for multiple symbols."""
        price_data = {}
        for symbol in symbols:
            try:
                bars = self.data_manager.fetch_ohlcv(symbol, timeframe, start, end)
                price_data[symbol] = bars
                logger.info(f"Fetched {len(bars)} bars for {symbol} {timeframe}")
            except Exception as e:
                logger.error(f"Failed to fetch {symbol}: {e}")
        return price_data

    def run_backtest(self, signals: list[ForexSignal],
                     price_data: dict[str, list[OHLCV]]) -> BacktestResult:
        """Run backtest on signals with price data."""
        engine = BacktestEngine(
            config=self.config.backtest,
            symbol_specs=self.config.symbols,
            risk_manager=self.risk_manager,
            regime_detector=self.regime_detector
        )
        return engine.run(signals, price_data)

    def analyze_regime(self, price_data: dict[str, list[OHLCV]]) -> dict[str, str]:
        """Get current regime for each symbol."""
        regimes = {}
        for symbol, bars in price_data.items():
            if len(bars) > 50:
                state = self.regime_detector.current_regime(bars)
                regimes[symbol] = state.regime.value
        return regimes

    def validate_signal(self, signal: ForexSignal) -> tuple[bool, str, Optional[dict]]:
        """Validate a signal against current risk rules."""
        open_signals = self.tracker.get_signals(status="tracked")
        open_trades = [s.signal for s in open_signals if s.status == "executed"]

        approved, reason, position_size = self.risk_manager.validate_signal(
            signal, self._account_state, open_trades
        )

        details = None
        if position_size:
            details = {
                "position_size": str(position_size),
                "risk_amount": str(position_size.risk_amount),
                "margin_required": str(position_size.margin_required),
            }

        return approved, reason, details

    def get_system_state(self) -> SystemState:
        """Get current system state snapshot."""
        open_signals = self.tracker.get_signals(status="tracked")
        regimes = {}
        for symbol in self.config.symbols:
            # Would need current price data for real regime
            regimes[symbol] = "UNKNOWN"

        return SystemState(
            account=self._account_state,
            open_signals=open_signals,
            open_trades=len([s for s in open_signals if s.status == "executed"]),
            current_regimes=regimes,
            last_update=datetime.now(timezone.utc)
        )

    def update_account_state(self, equity: Decimal, balance: Decimal,
                             open_positions: int = 0, daily_pnl: Decimal = Decimal("0")):
        """Update account state (e.g., from broker API)."""
        self._account_state = AccountState(
            equity=equity,
            balance=balance,
            free_margin=equity,  # Simplified
            used_margin=Decimal("0"),
            margin_level=Decimal("1000") if equity > 0 else Decimal("0"),
            open_positions=open_positions,
            daily_pnl=daily_pnl,
            max_drawdown_pct=Decimal("0"),
            currency=self.config.backtest.account_currency
        )

    def generate_report(self, result: BacktestResult, output_dir: Optional[Path] = None) -> dict:
        """Generate comprehensive backtest report."""
        output_dir = output_dir or Path(self.config.results_dir) / f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        output_dir.mkdir(parents=True, exist_ok=True)

        summary = result.summary()

        # Save equity curve
        if len(result.equity_curve) > 0:
            result.equity_curve.to_csv(output_dir / "equity_curve.csv")

        # Save trades
        import csv
        with open(output_dir / "trades.csv", 'w', newline='') as f:
            if result.trades:
                writer = csv.writer(f)
                writer.writerow([
                    "trade_id", "signal_id", "symbol", "direction", "entry_time",
                    "entry_price", "exit_time", "exit_price", "exit_reason",
                    "lots", "gross_pnl_pips", "net_pnl", "commission", "swap",
                    "r_multiple", "mae_pips", "mfe_pips", "duration_minutes"
                ])
                for t in result.trades:
                    writer.writerow([
                        t.trade_id, t.signal.signal_id, t.signal.symbol,
                        t.signal.direction.value, t.signal.timestamp.isoformat(),
                        str(t.entry_price.value), t.exit_time.isoformat() if t.exit_time else "",
                        str(t.exit_price.value) if t.exit_price else "",
                        t.exit_reason.value, str(t.position_size.lots),
                        str(t.gross_pnl_pips), str(t.net_pnl_currency),
                        str(t.commission), str(t.swap), str(t.r_multiple),
                        str(t.mae_pips), str(t.mfe_pips), t.duration_minutes
                    ])

        # Save summary
        import json
        with open(output_dir / "summary.json", 'w') as f:
            json.dump(summary, f, indent=2, default=str)

        # Save regime analysis
        regime_counts = {}
        for state in result.regime_states:
            regime_counts[state.regime.value] = regime_counts.get(state.regime.value, 0) + 1
        with open(output_dir / "regime_analysis.json", 'w') as f:
            json.dump(regime_counts, f, indent=2)

        logger.info(f"Report saved to {output_dir}")
        return {"summary": summary, "output_dir": str(output_dir)}


async def run_live_cycle(system: ForexSignalSystem, interval_minutes: int = 5):
    """Run continuous live signal monitoring cycle."""
    logger.info(f"Starting live cycle (interval: {interval_minutes} min)")

    while True:
        try:
            # Fetch signals
            signals = await system.fetch_live_signals()

            # Track new signals
            for signal in signals:
                system.tracker.track_signal(signal)

            # Validate and potentially execute (paper trading)
            for signal in signals:
                approved, reason, details = system.validate_signal(signal)
                if approved:
                    logger.info(f"Signal approved: {signal.symbol} {signal.direction.value} - {details}")
                    # In paper trading mode, would simulate entry here
                else:
                    logger.debug(f"Signal rejected: {signal.symbol} - {reason}")

        except Exception as e:
            logger.error(f"Live cycle error: {e}")

        await asyncio.sleep(interval_minutes * 60)


def create_system(config: Optional[SystemConfig] = None) -> ForexSignalSystem:
    """Factory function to create configured system."""
    return ForexSignalSystem(config)