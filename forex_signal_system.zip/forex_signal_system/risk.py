"""
Position sizing and risk management calculations.
Precision financial math with Decimal throughout.
"""

from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN
from typing import Literal, Optional
import math

from .types import PriceLevel, PositionSize, ForexSignal, AccountState
from .config import get_config, RiskConfig, SymbolSpec


class PositionSizer:
    """Calculate position sizes with multiple methodologies."""

    def __init__(self, risk_config: Optional[RiskConfig] = None, symbol_specs: Optional[dict[str, SymbolSpec]] = None):
        self.risk_config = risk_config or get_config().risk
        self.symbol_specs = symbol_specs or get_config().symbols

    def calculate(self, signal: ForexSignal, account: AccountState) -> PositionSize:
        """Calculate position size based on configured method."""
        method = self.risk_config.position_sizing_method

        if method == "fixed_fractional":
            return self._fixed_fractional(signal, account)
        elif method == "kelly":
            return self._kelly_criterion(signal, account)
        elif method == "volatility":
            return self._volatility_based(signal, account)
        else:
            return self._fixed_fractional(signal, account)

    def _fixed_fractional(self, signal: ForexSignal, account: AccountState) -> PositionSize:
        """Fixed fractional position sizing: risk fixed % of equity per trade."""
        spec = self.symbol_specs.get(signal.symbol)
        if not spec:
            raise ValueError(f"No symbol spec for {signal.symbol}")

        if not signal.entry_price or not signal.stop_loss:
            raise ValueError("Signal must have entry_price and stop_loss for position sizing")

        risk_pips = signal.entry_price.pips_from(signal.stop_loss)
        if risk_pips == 0:
            raise ValueError("Stop loss cannot equal entry price")

        # Risk amount in account currency
        risk_amount = account.equity * self.risk_config.risk_per_trade_pct

        # Pip value per lot for this symbol
        pip_value_per_lot = spec.pip_value_per_lot

        # Calculate lots: risk_amount / (risk_pips * pip_value_per_lot)
        lots = risk_amount / (Decimal(str(risk_pips)) * pip_value_per_lot)

        # Round to lot step
        lots = self._round_lots(lots, spec)

        # Clamp to min/max
        lots = max(spec.min_lot, min(spec.max_lot, lots))

        # Recalculate actual risk with rounded lots
        units = lots * Decimal("100000")  # Standard lot = 100k units
        actual_risk = Decimal(str(risk_pips)) * pip_value_per_lot * lots
        margin_required = units * spec.margin_rate * signal.entry_price.value

        return PositionSize(
            lots=lots,
            units=units,
            risk_amount=actual_risk.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            risk_pct=(actual_risk / account.equity).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP),
            margin_required=margin_required.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            pip_value=(pip_value_per_lot * lots).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        )

    def _kelly_criterion(self, signal: ForexSignal, account: AccountState) -> PositionSize:
        """Kelly criterion sizing (requires historical win rate / avg win/loss)."""
        # This would need historical performance data
        # For now, fall back to fractional with Kelly fraction
        base_size = self._fixed_fractional(signal, account)
        kelly_lots = base_size.lots * self.risk_config.kelly_fraction
        spec = self.symbol_specs.get(signal.symbol)

        kelly_lots = self._round_lots(kelly_lots, spec)
        kelly_lots = max(spec.min_lot, min(spec.max_lot, kelly_lots))

        units = kelly_lots * Decimal("100000")
        risk_pips = signal.entry_price.pips_from(signal.stop_loss)
        pip_value_per_lot = spec.pip_value_per_lot
        actual_risk = Decimal(str(risk_pips)) * pip_value_per_lot * kelly_lots
        margin_required = units * spec.margin_rate * signal.entry_price.value

        return PositionSize(
            lots=kelly_lots,
            units=units,
            risk_amount=actual_risk.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            risk_pct=(actual_risk / account.equity).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP),
            margin_required=margin_required.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
            pip_value=(pip_value_per_lot * kelly_lots).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        )

    def _volatility_based(self, signal: ForexSignal, account: AccountState) -> PositionSize:
        """Volatility-adjusted sizing (inverse to ATR)."""
        # Would need ATR data - fallback to fixed fractional for now
        return self._fixed_fractional(signal, account)

    def _round_lots(self, lots: Decimal, spec: SymbolSpec) -> Decimal:
        """Round lots to broker's lot step."""
        step = spec.lot_step
        if step == 0:
            return lots
        return (lots / step).quantize(Decimal("1"), rounding=ROUND_DOWN) * step


class RiskManager:
    """Pre-trade risk validation and portfolio-level risk controls."""

    def __init__(self, risk_config: Optional[RiskConfig] = None, symbol_specs: Optional[dict[str, SymbolSpec]] = None):
        self.risk_config = risk_config or get_config().risk
        self.symbol_specs = symbol_specs or get_config().symbols
        self.sizer = PositionSizer(risk_config, symbol_specs)

    def validate_signal(self, signal: ForexSignal, account: AccountState,
                        open_positions: list[ForexSignal]) -> tuple[bool, str, Optional[PositionSize]]:
        """
        Comprehensive pre-trade validation.
        Returns: (approved, reason, position_size)
        """
        # 1. Basic signal completeness
        if not signal.entry_price or not signal.stop_loss:
            return False, "Signal missing entry_price or stop_loss", None

        if not signal.take_profit:
            return False, "Signal missing take_profit (required for R:R check)", None

        # 2. Risk:Reward check
        rr = signal.risk_reward_ratio()
        if rr is None or rr < self.risk_config.min_risk_reward:
            return False, f"R:R {rr} below minimum {self.risk_config.min_risk_reward}", None

        # 3. Position size calculation
        try:
            position_size = self.sizer.calculate(signal, account)
        except Exception as e:
            return False, f"Position sizing failed: {e}", None

        # 4. Account-level risk gates
        can_trade, reason = account.can_trade(
            position_size.risk_amount,
            position_size.margin_required,
            self.risk_config.max_daily_loss_pct
        )
        if not can_trade:
            return False, f"Account risk gate: {reason}", position_size

        # 5. Concurrent position limits
        if len(open_positions) >= self.risk_config.max_concurrent_positions:
            return False, f"Max concurrent positions ({self.risk_config.max_concurrent_positions}) reached", position_size

        # 6. Correlated exposure check
        correlated_count = self._count_correlated_exposure(signal.symbol, open_positions)
        if correlated_count >= self.risk_config.max_correlated_exposure:
            return False, f"Max correlated exposure ({self.risk_config.max_correlated_exposure}) for {signal.symbol[:3]}/{signal.symbol[3:]}", position_size

        # 7. Spread check (would need current spread data)
        # 8. Slippage check (would need execution quality data)

        return True, "Approved", position_size

    def _count_correlated_exposure(self, symbol: str, open_positions: list[ForexSignal]) -> int:
        """Count positions sharing base or quote currency."""
        base = symbol[:3]
        quote = symbol[3:]
        count = 0
        for pos in open_positions:
            if pos.symbol[:3] in (base, quote) or pos.symbol[3:] in (base, quote):
                count += 1
        return count

    def check_drawdown_halt(self, account: AccountState) -> tuple[bool, str]:
        """Check if max drawdown halt is triggered."""
        if account.max_drawdown_pct >= self.risk_config.max_drawdown_pct:
            return True, f"Max drawdown halt triggered: {account.max_drawdown_pct:.2%} >= {self.risk_config.max_drawdown_pct:.2%}"
        return False, "OK"

    def calculate_portfolio_risk(self, positions: list[tuple[ForexSignal, PositionSize]], account: AccountState) -> dict:
        """Calculate aggregate portfolio risk metrics."""
        total_risk = sum(p[1].risk_amount for p in positions)
        total_margin = sum(p[1].margin_required for p in positions)

        # Currency exposure
        currency_exposure = {}
        for signal, size in positions:
            base = signal.symbol[:3]
            quote = signal.symbol[3:]
            direction = 1 if signal.is_buy else -1
            currency_exposure[base] = currency_exposure.get(base, Decimal("0")) + direction * size.units
            currency_exposure[quote] = currency_exposure.get(quote, Decimal("0")) - direction * size.units

        return {
            "total_risk_amount": total_risk,
            "total_risk_pct": total_risk / account.equity if account.equity > 0 else Decimal("0"),
            "total_margin": total_margin,
            "margin_utilization": total_margin / account.equity if account.equity > 0 else Decimal("0"),
            "free_margin": account.equity - total_margin,
            "currency_exposure": currency_exposure,
            "position_count": len(positions),
        }


def create_risk_manager(risk_config: Optional[RiskConfig] = None,
                        symbol_specs: Optional[dict[str, SymbolSpec]] = None) -> RiskManager:
    return RiskManager(risk_config, symbol_specs)