"""
Historical market data provider with caching and validation.
Supports multiple sources with unified interface.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Optional, Literal
import pandas as pd
import numpy as np
import hashlib
import json
import logging

from .types import OHLCV, PriceLevel
from .config import get_config, DataConfig, SymbolSpec

logger = logging.getLogger(__name__)


class DataProvider(ABC):
    """Abstract base for data providers."""

    @abstractmethod
    def fetch(self, symbol: str, timeframe: str, start: datetime, end: datetime) -> pd.DataFrame:
        """Fetch OHLCV data as DataFrame with columns: open, high, low, close, volume."""
        pass

    @abstractmethod
    def get_latest_price(self, symbol: str) -> PriceLevel:
        """Get current bid/ask midpoint."""
        pass


class YahooFinanceProvider(DataProvider):
    """Yahoo Finance data provider (free, no API key needed)."""

    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._symbol_map = {
            "EURUSD": "EURUSD=X",
            "GBPUSD": "GBPUSD=X",
            "USDJPY": "USDJPY=X",
            "USDCHF": "USDCHF=X",
            "AUDUSD": "AUDUSD=X",
            "USDCAD": "USDCAD=X",
            "NZDUSD": "NZDUSD=X",
            "EURGBP": "EURGBP=X",
            "EURJPY": "EURJPY=X",
            "AUDJPY": "AUDJPY=X",
        }

    def _yahoo_symbol(self, symbol: str) -> str:
        return self._symbol_map.get(symbol.upper(), f"{symbol.upper()}=X")

    def _cache_key(self, symbol: str, timeframe: str, start: datetime, end: datetime) -> str:
        key_str = f"{symbol}_{timeframe}_{start.isoformat()}_{end.isoformat()}"
        return hashlib.md5(key_str.encode()).hexdigest()[:16]

    def _cache_path(self, key: str) -> Path:
        return self.cache_dir / f"{key}.parquet"

    def fetch(self, symbol: str, timeframe: str, start: datetime, end: datetime) -> pd.DataFrame:
        import yfinance as yf

        ysymbol = self._yahoo_symbol(symbol)
        key = self._cache_key(symbol, timeframe, start, end)
        cache_file = self._cache_path(key)

        # Check cache
        if cache_file.exists():
            try:
                df = pd.read_parquet(cache_file)
                # Validate cache covers requested range
                if df.index[0] <= start and df.index[-1] >= end:
                    logger.debug(f"Cache hit: {symbol} {timeframe}")
                    return df.loc[start:end]
            except Exception as e:
                logger.warning(f"Cache read failed: {e}")

        # Map timeframe to yfinance interval
        interval_map = {
            "M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
            "H1": "1h", "H4": "4h", "D1": "1d", "W1": "1wk"
        }
        interval = interval_map.get(timeframe, "15m")

        # yfinance limits: 1m data only last 7 days, 1h last 730 days
        if interval in ("1m", "5m") and (end - start).days > 7:
            logger.warning(f"Yahoo Finance limits {interval} to 7 days, truncating")
            start = end - timedelta(days=7)

        try:
            ticker = yf.Ticker(ysymbol)
            df = ticker.history(
                start=start,
                end=end + timedelta(days=1),  # Inclusive end
                interval=interval,
                auto_adjust=False,
                actions=False
            )

            if df.empty:
                raise ValueError(f"No data returned for {symbol}")

            # Standardize columns
            df = df.rename(columns={
                "Open": "open", "High": "high", "Low": "low", "Close": "close", "Volume": "volume"
            })[["open", "high", "low", "close", "volume"]]

            # Ensure UTC timezone
            if df.index.tz is None:
                df.index = df.index.tz_localize(timezone.utc)
            else:
                df.index = df.index.tz_convert(timezone.utc)

            # Cache
            df.to_parquet(cache_file, compression="snappy")
            logger.info(f"Fetched {len(df)} bars for {symbol} {timeframe}")

            return df.loc[start:end]

        except Exception as e:
            logger.error(f"Yahoo Finance fetch failed for {symbol}: {e}")
            raise

    def get_latest_price(self, symbol: str) -> PriceLevel:
        import yfinance as yf
        ysymbol = self._yahoo_symbol(symbol)
        ticker = yf.Ticker(ysymbol)
        info = ticker.fast_info
        price = Decimal(str(info.last_price))
        return PriceLevel(price, symbol)


class CSVProvider(DataProvider):
    """Local CSV data provider for custom datasets."""

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir

    def fetch(self, symbol: str, timeframe: str, start: datetime, end: datetime) -> pd.DataFrame:
        # Expected filename: SYMBOL_TIMEFRAME.csv
        file_path = self.data_dir / f"{symbol.upper()}_{timeframe}.csv"
        if not file_path.exists():
            raise FileNotFoundError(f"Data file not found: {file_path}")

        df = pd.read_csv(file_path, parse_dates=["timestamp"], index_col="timestamp")
        df.columns = [c.lower() for c in df.columns]

        required = ["open", "high", "low", "close", "volume"]
        if not all(c in df.columns for c in required):
            raise ValueError(f"CSV missing required columns: {required}")

        if df.index.tz is None:
            df.index = df.index.tz_localize(timezone.utc)

        return df.loc[start:end]

    def get_latest_price(self, symbol: str) -> PriceLevel:
        file_path = self.data_dir / f"{symbol.upper()}_M1.csv"
        if not file_path.exists():
            raise FileNotFoundError(f"No M1 data for latest price: {file_path}")
        df = pd.read_csv(file_path, parse_dates=["timestamp"], index_col="timestamp")
        last_close = Decimal(str(df["close"].iloc[-1]))
        return PriceLevel(last_close, symbol)


class DataManager:
    """Unified data access with provider fallback and validation."""

    def __init__(self, config: Optional[DataConfig] = None):
        self.config = config or get_config().data
        self.providers: dict[str, DataProvider] = {}
        self._init_providers()
        self._symbol_specs = get_config().symbols

    def _init_providers(self):
        if self.config.provider in ("yahoo", "auto"):
            self.providers["yahoo"] = YahooFinanceProvider(self.config.cache_dir)
        if self.config.provider == "csv":
            self.providers["csv"] = CSVProvider(self.config.cache_dir)
        # Add more providers as needed

    def get_provider(self, name: Optional[str] = None) -> DataProvider:
        name = name or self.config.provider
        if name not in self.providers:
            raise ValueError(f"Provider not available: {name}. Available: {list(self.providers.keys())}")
        return self.providers[name]

    def fetch_ohlcv(self, symbol: str, timeframe: str, start: datetime, end: datetime,
                    provider: Optional[str] = None) -> list[OHLCV]:
        """Fetch and validate OHLCV data, return as typed objects."""
        df = self.get_provider(provider).fetch(symbol, timeframe, start, end)

        if self.config.validate_data:
            df = self._validate_ohlcv(df, symbol)

        spec = self._symbol_specs.get(symbol)
        ohlcv_list = []
        for ts, row in df.iterrows():
            try:
                ohlcv_list.append(OHLCV(
                    timestamp=ts.to_pydatetime() if hasattr(ts, 'to_pydatetime') else ts,
                    open=PriceLevel(Decimal(str(row["open"])), symbol),
                    high=PriceLevel(Decimal(str(row["high"])), symbol),
                    low=PriceLevel(Decimal(str(row["low"])), symbol),
                    close=PriceLevel(Decimal(str(row["close"])), symbol),
                    volume=Decimal(str(row.get("volume", 0)))
                ))
            except Exception as e:
                logger.warning(f"Invalid bar at {ts}: {e}")
                continue

        return ohlcv_list

    def _validate_ohlcv(self, df: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Validate and clean OHLCV data."""
        original_len = len(df)

        # Remove rows with NaN
        df = df.dropna(subset=["open", "high", "low", "close"])

        # Validate OHLC relationships
        invalid = (df["low"] > df["open"]) | (df["open"] > df["high"]) | \
                  (df["low"] > df["close"]) | (df["close"] > df["high"])
        if invalid.any():
            logger.warning(f"{symbol}: {invalid.sum()} bars with invalid OHLC, removing")
            df = df[~invalid]

        # Remove zero volume bars (optional)
        # df = df[df["volume"] > 0]

        # Check for gaps
        if self.config.fill_gaps and len(df) > 1:
            expected_freq = pd.infer_freq(df.index[:10])
            if expected_freq:
                full_range = pd.date_range(df.index[0], df.index[-1], freq=expected_freq, tz=timezone.utc)
                missing = full_range.difference(df.index)
                if len(missing) > 0:
                    gap_minutes = len(missing) * pd.Timedelta(expected_freq).total_seconds() / 60
                    if gap_minutes <= self.config.max_gap_minutes:
                        logger.info(f"{symbol}: Filling {len(missing)} gaps ({gap_minutes:.0f} min)")
                        df = df.reindex(full_range).interpolate(method="time")
                    else:
                        logger.warning(f"{symbol}: Large gap detected ({gap_minutes:.0f} min), not filling")

        logger.debug(f"{symbol}: Validated {original_len} -> {len(df)} bars")
        return df

    def to_dataframe(self, ohlcv_list: list[OHLCV]) -> pd.DataFrame:
        """Convert OHLCV list to DataFrame for vectorized operations."""
        if not ohlcv_list:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

        data = {
            "open": [float(c.open.value) for c in ohlcv_list],
            "high": [float(c.high.value) for c in ohlcv_list],
            "low": [float(c.low.value) for c in ohlcv_list],
            "close": [float(c.close.value) for c in ohlcv_list],
            "volume": [float(c.volume) for c in ohlcv_list],
        }
        index = pd.DatetimeIndex([c.timestamp for c in ohlcv_list], tz=timezone.utc)
        return pd.DataFrame(data, index=index)

    def get_latest_price(self, symbol: str) -> PriceLevel:
        return self.get_provider().get_latest_price(symbol)


# Convenience function
def create_data_manager(config: Optional[DataConfig] = None) -> DataManager:
    return DataManager(config)